import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ShoppingCart, X, Heart, RefreshCcw, Info, ArrowRight, Sparkles } from "lucide-react";
import { useLocation } from "wouter";
import { useCart } from "@/contexts/CartContext";
import { toast } from "sonner";

// ─── PRODUCTS DATA ──────────────────────────────────────────────────────────────

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
  description: string;
}

const PRODUCTS: Product[] = [
  {
    id: 1,
    name: "iPhone 15 Pro Max",
    price: 1199,
    image: "https://images.unsplash.com/photo-1696446701796-da61225697cc?w=1200&q=90",
    category: "Смартфоны",
    description: "Титановый корпус, чип A17 Pro и лучшая в мире камера для мобильных устройств. Ощутите мощь в каждом кадре.",
  },
  {
    id: 2,
    name: "MacBook Air M3",
    price: 1299,
    image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=1200&q=90",
    category: "Ноутбуки",
    description: "Невероятно тонкий и мощный. Работайте весь день без подзарядки с новым чипом M3.",
  },
  {
    id: 3,
    name: "AirPods Max",
    price: 549,
    image: "https://images.unsplash.com/photo-1613040809024-b4ef7ba99bc3?w=1200&q=90",
    category: "Наушники",
    description: "Идеальное сочетание высокого качества звука и комфорта. Погрузитесь в музыку полностью.",
  },
  {
    id: 4,
    name: "Apple Watch Ultra 2",
    price: 799,
    image: "https://images.unsplash.com/photo-1434493907317-a46b53b81882?w=1200&q=90",
    category: "Часы",
    description: "Самые прочные и функциональные часы Apple. Созданы для экстремальных приключений.",
  },
  {
    id: 5,
    name: "iPad Pro M2",
    price: 999,
    image: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=1200&q=90",
    category: "Планшеты",
    description: "Дисплей Liquid Retina XDR и невероятная скорость. Ваш идеальный инструмент для творчества.",
  },
  {
    id: 6,
    name: "Sony PlayStation 5",
    price: 499,
    image: "https://images.unsplash.com/photo-1606813907291-d86efa9b94db?w=1200&q=90",
    category: "Игры",
    description: "Новое поколение игр с мгновенной загрузкой и тактильной отдачей. Играйте без границ.",
  },
  {
    id: 7,
    name: "Canon EOS R5",
    price: 3899,
    image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=1200&q=90",
    category: "Камеры",
    description: "Профессиональная беззеркальная камера с возможностью записи видео 8K. Создавайте шедевры.",
  },
  {
    id: 8,
    name: "Dyson V15 Detect",
    price: 749,
    image: "https://images.unsplash.com/photo-1558317374-067fb5f30001?w=1200&q=90",
    category: "Дом",
    description: "Самый мощный и интеллектуальный пылесос. Лазерный луч обнаруживает невидимую пыль.",
  },
];

// ─── CARD COMPONENT ────────────────────────────────────────────────────────────

interface CardProps {
  product: Product;
  onSwipe: (direction: "left" | "right") => void;
}

function Card({ product, onSwipe }: CardProps) {
  const [dragX, setDragX] = useState(0);

  return (
    <motion.div
      drag="x"
      dragConstraints={{ left: -1200, right: 1200 }}
      onDrag={(e, info) => setDragX(info.offset.x)}
      onDragEnd={(e, info) => {
        if (info.offset.x > 150) onSwipe("right");
        else if (info.offset.x < -150) onSwipe("left");
        setDragX(0);
      }}
      initial={{ scale: 0.9, opacity: 0, y: 30 }}
      animate={{ scale: 1, opacity: 1, y: 0 }}
      exit={{ 
        x: dragX > 0 ? 1500 : -1500, 
        opacity: 0, 
        rotate: dragX > 0 ? 25 : -25,
        transition: { duration: 0.5, ease: "easeInOut" } 
      }}
      style={{ rotate: dragX / 30 }}
      className="absolute inset-0 z-10 touch-none"
    >
      <div className="w-full h-full bg-white rounded-[3rem] shadow-[0_30px_100px_rgba(0,0,0,0.08)] overflow-hidden border border-gray-100 flex flex-col md:flex-row">
        {/* Image Section - Large for Desktop */}
        <div className="relative w-full md:w-3/5 h-[50%] md:h-full overflow-hidden bg-gray-50">
          <motion.img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover"
            initial={{ scale: 1.1 }}
            animate={{ scale: 1 }}
            transition={{ duration: 1.2 }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/20 via-transparent to-transparent hidden md:block" />
          
          {/* Indicators */}
          <AnimatePresence>
            {dragX > 80 && (
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0 }}
                className="absolute top-1/2 left-10 -translate-y-1/2 z-20 bg-green-500 text-white px-8 py-4 rounded-full font-black text-2xl shadow-2xl flex items-center gap-3 border-4 border-white"
              >
                <Heart className="w-8 h-8 fill-white" /> ХОЧУ!
              </motion.div>
            )}
            {dragX < -80 && (
              <motion.div
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0 }}
                className="absolute top-1/2 right-10 -translate-y-1/2 z-20 bg-red-500 text-white px-8 py-4 rounded-full font-black text-2xl shadow-2xl flex items-center gap-3 border-4 border-white"
              >
                <X className="w-8 h-8" /> МИМО
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Info Section - Side panel for Desktop */}
        <div className="w-full md:w-2/5 p-10 md:p-14 flex flex-col justify-between bg-white">
          <div className="space-y-8">
            <div className="space-y-2">
              <span className="text-[12px] font-black text-blue-600 uppercase tracking-[0.2em]">{product.category}</span>
              <h2 className="text-4xl md:text-5xl font-black text-gray-900 tracking-tighter leading-none">
                {product.name}
              </h2>
            </div>
            
            <p className="text-gray-500 text-lg md:text-xl font-medium leading-relaxed">
              {product.description}
            </p>

            <div className="flex flex-wrap gap-3">
              {["New", "In Stock", "Free Delivery"].map(tag => (
                <span key={tag} className="px-4 py-2 bg-gray-50 rounded-xl text-xs font-bold text-gray-400 uppercase tracking-widest border border-gray-100">
                  {tag}
                </span>
              ))}
            </div>
          </div>

          <div className="space-y-8">
            <div className="flex flex-col">
              <span className="text-xs font-black text-gray-300 uppercase tracking-[0.3em] mb-2">Стоимость</span>
              <span className="text-6xl font-black text-gray-900">${product.price}</span>
            </div>

            <div className="flex gap-4">
              <button 
                onClick={() => onSwipe("left")}
                className="flex-1 py-5 bg-gray-50 text-gray-400 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-red-50 hover:text-red-500 transition-all active:scale-95 border border-gray-100"
              >
                Пропустить
              </button>
              <button 
                onClick={() => onSwipe("right")}
                className="flex-[2] py-5 bg-gray-900 text-white rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-blue-600 transition-all active:scale-95 shadow-xl shadow-gray-200 flex items-center justify-center gap-3"
              >
                В корзину <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// ─── MAIN PAGE ─────────────────────────────────────────────────────────────────

export default function Swipeee() {
  useEffect(() => {
    document.body.style.fontFamily = "'Montserrat', sans-serif";
    return () => {
      document.body.style.fontFamily = "";
    };
  }, []);

  const [, navigate] = useLocation();
  const { items: cartItems, addItem, total } = useCart();
  const [products, setProducts] = useState<Product[]>(PRODUCTS);

  const handleSwipe = (direction: "left" | "right") => {
    const current = products[0];
    if (!current) return;

    if (direction === "right") {
      addItem({
        id: current.id,
        name: current.name,
        price: current.price,
        image: current.image,
        category: current.category,
      });
      toast.success(`${current.name} добавлен!`, {
        style: { borderRadius: '24px', padding: '20px', background: '#000', color: '#fff' }
      });
    }
    
    setProducts(products.slice(1));
  };

  return (
    <div className="min-h-screen bg-[#FAFAFA] text-gray-900 overflow-hidden flex flex-col">
      {/* Global Desktop Header */}
      <header className="w-full bg-white/70 backdrop-blur-2xl border-b border-gray-100 sticky top-0 z-50">
        <div className="max-w-[1800px] mx-auto px-10 h-24 flex items-center justify-between">
          <button onClick={() => navigate("/")} className="flex items-center gap-4 group cursor-pointer">
            <div className="w-12 h-12 bg-gray-900 rounded-2xl flex items-center justify-center text-white group-hover:rotate-12 transition-transform">
              <svg viewBox="0 0 256 256" className="w-7 h-7" fill="currentColor">
                <path d="M 0 128 C 70.692 128 128 185.308 128 256 L 64 256 C 64 220.654 35.346 192 0 192 Z M 256 192 C 220.654 192 192 220.654 192 256 L 128 256 C 128 185.308 185.308 128 256 128 Z M 128 0 C 128 70.692 70.692 128 0 128 L 0 64 C 35.346 64 64 35.346 64 0 Z M 192 0 C 192 35.346 220.654 64 256 64 L 256 128 C 185.308 128 128 70.692 128 0 Z" />
              </svg>
            </div>
            <span className="text-2xl font-black tracking-tighter">CoiNIS</span>
          </button>

          <div className="flex items-center gap-8">
            <div className="hidden lg:flex items-center gap-10 text-sm font-bold uppercase tracking-widest text-gray-400">
              <button onClick={() => navigate("/")} className="hover:text-gray-900 transition-colors">Главная</button>
              <button onClick={() => navigate("/catalog")} className="hover:text-gray-900 transition-colors">Каталог</button>
              <button className="text-gray-900 border-b-2 border-gray-900 pb-1">Swipeee</button>
            </div>
            <button 
              onClick={() => navigate("/cart")}
              className="flex items-center gap-4 bg-gray-900 text-white px-8 py-4 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-blue-600 transition-all active:scale-95 shadow-xl shadow-gray-200"
            >
              <ShoppingCart className="w-5 h-5" />
              <span>Корзина</span>
              <span className="w-6 h-6 bg-white/20 rounded-lg flex items-center justify-center text-[10px]">{cartItems.length}</span>
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 flex flex-col lg:flex-row max-w-[1800px] mx-auto w-full p-6 lg:p-10 gap-10">
        {/* Left Side - Card Stack (The "Game") */}
        <div className="flex-1 relative flex flex-col">
          <div className="mb-10 space-y-2">
            <div className="flex items-center gap-3">
              <div className="px-3 py-1 bg-blue-600 text-white text-[10px] font-black uppercase tracking-widest rounded-lg">Live</div>
              <h2 className="text-sm font-black text-gray-400 uppercase tracking-[0.3em]">Рекомендации для вас</h2>
            </div>
            <h1 className="text-5xl font-black tracking-tighter">Найдите свой стиль</h1>
          </div>

          <div className="relative flex-1 min-h-[600px] lg:min-h-0">
            <AnimatePresence mode="popLayout">
              {products.length > 0 ? (
                <Card
                  key={products[0].id}
                  product={products[0]}
                  onSwipe={handleSwipe}
                />
              ) : (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="absolute inset-0 bg-white rounded-[4rem] shadow-2xl border border-gray-100 flex flex-col items-center justify-center p-20 text-center"
                >
                  <div className="w-32 h-32 bg-blue-50 rounded-full flex items-center justify-center mb-10">
                    <RefreshCcw className="w-12 h-12 text-blue-600" />
                  </div>
                  <h2 className="text-5xl font-black text-gray-900 tracking-tighter mb-6">
                    На сегодня всё!
                  </h2>
                  <p className="text-gray-400 text-xl font-medium mb-12 max-w-md mx-auto leading-relaxed">
                    Вы просмотрели все актуальные предложения. Хотите начать сначала?
                  </p>
                  <button
                    onClick={() => {
                      setProducts(PRODUCTS);
                    }}
                    className="px-12 py-6 bg-gray-900 text-white rounded-[2rem] font-black text-lg uppercase tracking-widest hover:bg-black transition-all active:scale-95 shadow-2xl shadow-gray-300"
                  >
                    Повторить поиск
                  </button>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Background Stacks */}
            {products.length > 1 && (
              <div className="absolute inset-0 -z-10 translate-y-6 translate-x-6 scale-[0.96] opacity-30 bg-white rounded-[3rem] shadow-lg border border-gray-100" />
            )}
            {products.length > 2 && (
              <div className="absolute inset-0 -z-20 translate-y-12 translate-x-12 scale-[0.92] opacity-10 bg-white rounded-[3rem] shadow-lg border border-gray-100" />
            )}
          </div>
        </div>

        {/* Right Side - Cart Sidebar (Desktop only) */}
        <aside className="hidden xl:flex w-[450px] flex-col gap-8">
          {/* Summary Box */}
          <div className="bg-white rounded-[3rem] p-10 border border-gray-100 shadow-sm space-y-8">
            <div className="flex items-center justify-between">
              <h3 className="text-2xl font-black tracking-tighter">Ваша корзина</h3>
              <Sparkles className="w-6 h-6 text-blue-600" />
            </div>

            <div className="space-y-4">
              <div className="flex justify-between text-sm font-bold text-gray-400 uppercase tracking-widest">
                <span>Товаров</span>
                <span className="text-gray-900">{cartItems.length}</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-gray-400 uppercase tracking-widest">
                <span>Доставка</span>
                <span className="text-green-500">Бесплатно</span>
              </div>
              <div className="pt-6 border-t border-gray-50 flex justify-between items-end">
                <span className="text-xs font-black text-gray-300 uppercase tracking-[0.3em]">Итого</span>
                <span className="text-5xl font-black text-blue-600">${total.toFixed(0)}</span>
              </div>
            </div>

            <button 
              onClick={() => navigate("/cart")}
              className="w-full py-6 bg-blue-600 text-white rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-blue-700 transition-all active:scale-95 shadow-xl shadow-blue-100"
            >
              Оформить заказ
            </button>
          </div>

          {/* Recent Likes List */}
          <div className="flex-1 bg-white rounded-[3rem] p-10 border border-gray-100 shadow-sm overflow-hidden flex flex-col">
            <h3 className="text-xl font-black tracking-tighter mb-8">Недавно добавлено</h3>
            <div className="flex-1 overflow-y-auto space-y-6 pr-2 custom-scrollbar">
              {cartItems.length > 0 ? (
                cartItems.map((item) => (
                  <div key={item.id} className="flex gap-5 group cursor-pointer" onClick={() => navigate("/cart")}>
                    <div className="w-20 h-20 rounded-2xl overflow-hidden bg-gray-50 flex-shrink-0">
                      <img src={item.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                    </div>
                    <div className="flex flex-col justify-center">
                      <p className="text-[10px] font-black text-blue-600 uppercase tracking-widest mb-1">{item.category}</p>
                      <p className="font-black text-gray-900 leading-tight mb-1">{item.name}</p>
                      <p className="text-sm font-bold text-gray-400">${item.price}</p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-center opacity-30 grayscale">
                  <ShoppingCart className="w-12 h-12 mb-4" />
                  <p className="text-sm font-bold uppercase tracking-widest">Корзина пуста</p>
                </div>
              )}
            </div>
          </div>
        </aside>
      </main>

      {/* Footer / Instructions */}
      <footer className="w-full p-10 text-center">
        <div className="inline-flex items-center gap-10 px-10 py-5 bg-white rounded-full border border-gray-100 shadow-sm text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">
          <div className="flex items-center gap-3"><kbd className="px-2 py-1 bg-gray-100 rounded text-gray-900">←</kbd> Пропустить</div>
          <div className="w-1 h-1 rounded-full bg-gray-200" />
          <div className="flex items-center gap-3"><kbd className="px-2 py-1 bg-gray-100 rounded text-gray-900">→</kbd> В корзину</div>
          <div className="w-1 h-1 rounded-full bg-gray-200" />
          <div className="flex items-center gap-3 underline decoration-blue-600 underline-offset-4">Используйте мышь для свайпа</div>
        </div>
      </footer>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #eee; border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #ddd; }
      `}</style>
    </div>
  );
}
