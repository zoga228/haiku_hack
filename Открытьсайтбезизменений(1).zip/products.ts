import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import { searchProducts } from "../brightdata";
import { RECOMMENDATIONS } from "../recommendations";

export const productsRouter = router({
  search: publicProcedure
    .input(z.object({ query: z.string().optional() }))
    .query(async ({ input }) => {
      const { query } = input;
      
      // If no query, return recommendations
      if (!query || query.trim() === "") {
        return RECOMMENDATIONS;
      }

      try {
        const results = await searchProducts(query);
        
        if (results.length === 0) {
          // If API returns nothing, try to filter recommendations as fallback
          const filtered = RECOMMENDATIONS.filter(p => 
            p.title.toLowerCase().includes(query.toLowerCase())
          );
          return filtered;
        }

        return results.map(p => ({
          id: p.asin,
          title: p.name,
          description: `Product from ${p.domain}`,
          price: p.final_price,
          currency: p.currency,
          image: p.image,
          category: "Marketplace",
          url: p.url,
          rating: p.rating,
          num_ratings: p.num_ratings
        }));
      } catch (error) {
        console.error("Product search failed:", error);
        return RECOMMENDATIONS.filter(p => 
          p.title.toLowerCase().includes(query.toLowerCase())
        );
      }
    }),
});
