import bcrypt from "bcryptjs";

export interface User {
  id: number;
  name: string;
  email: string;
  password?: string;
  created_at: string;
}

// Simple In-Memory Database for Hackathon stability
interface VerificationCode {
  userId: number;
  code: string;
  expiresAt: number;
}

class InMemoryDB {
  private users: User[] = [];
  private verificationCodes: VerificationCode[] = [];
  private nextId = 1;

  async create(name: string, email: string, password: string) {
    const hashedPassword = await bcrypt.hash(password, 10);
    const user: User = {
      id: this.nextId++,
      name,
      email,
      password: hashedPassword,
      created_at: new Date().toISOString(),
    };
    this.users.push(user);
    return user;
  }

  getByEmail(email: string) {
    return this.users.find(u => u.email === email) || null;
  }

  getById(id: number) {
    const user = this.users.find(u => u.id === id);
    if (!user) return null;
    const { password, ...safeUser } = user;
    return safeUser;
  }

  async verifyPassword(user: User, password: string) {
    if (!user.password) return false;
    return bcrypt.compare(password, user.password);
  }

  generateVerificationCode(userId: number) {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = Date.now() + 10 * 60 * 1000;
    this.verificationCodes = this.verificationCodes.filter(vc => vc.userId !== userId);
    this.verificationCodes.push({ userId, code, expiresAt });
    return code;
  }

  verifyCode(userId: number, code: string) {
    const vc = this.verificationCodes.find(v => v.userId === userId && v.code === code);
    if (!vc) return false;
    if (vc.expiresAt < Date.now()) {
      this.verificationCodes = this.verificationCodes.filter(v => v !== vc);
      return false;
    }
    this.verificationCodes = this.verificationCodes.filter(v => v !== vc);
    return true;
  }
}

export const userDb = new InMemoryDB();
export default userDb;
