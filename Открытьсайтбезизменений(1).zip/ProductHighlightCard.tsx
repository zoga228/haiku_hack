"use client";

import * as React from "react";
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { cn } from "@/lib/utils";

// Define the properties for the ProductHighlightCard component
interface ProductHighlightCardProps extends React.HTMLAttributes<HTMLDivElement> {
  categoryIcon: React.ReactNode;
  category: string;
  title: string;
  description: string | React.ReactNode;
  imageSrc: string;
  imageAlt: string;
}

export const ProductHighlightCard = React.forwardRef<HTMLDivElement, ProductHighlightCardProps>(
  ({ className, categoryIcon, category, title, description, imageSrc, imageAlt, ...props }, ref) => {
    
    // --- Animation Logic for 3D Tilt Effect ---
    const mouseX = useMotionValue(0);
    const mouseY = useMotionValue(0);

    const handleMouseMove = ({ clientX, clientY, currentTarget }: React.MouseEvent) => {
      const { left, top } = currentTarget.getBoundingClientRect();
      mouseX.set(clientX - left);
      mouseY.set(clientY - top);
    };

    // Transform mouse position into a rotation value
    const rotateX = useTransform(mouseY, [0, 350], [10, -10]);
    const rotateY = useTransform(mouseX, [0, 350], [-10, 10]);
    
    // Apply spring physics for a smoother animation
    const springConfig = { stiffness: 300, damping: 20 };
    const springRotateX = useSpring(rotateX, springConfig);
    const springRotateY = useSpring(rotateY, springConfig);
    
    // --- Animation Logic for Glow Effect ---
    const glowX = useTransform(mouseX, [0, 350], [0, 100]);
    const glowY = useTransform(mouseY, [0, 350], [0, 100]);
    const glowOpacity = useTransform(mouseX, [0, 350], [0, 0.5]);

    return (
      <motion.div
        ref={ref}
        onMouseMove={handleMouseMove}
        onMouseLeave={() => {
          mouseX.set(0);
          mouseY.set(0);
        }}
        style={{
          rotateX: springRotateX,
          rotateY: springRotateY,
          transformStyle: "preserve-3d",
        }}
        className={cn(
          "relative h-[380px] w-full max-w-[350px] rounded-2xl bg-gradient-to-br from-card to-card/80 shadow-lg transition-shadow duration-300 hover:shadow-2xl overflow-hidden",
          className
        )}
        {...props}
      >
        <div style={{ transform: "translateZ(20px)", transformStyle: "preserve-3d" }} className="absolute inset-4 rounded-xl bg-card-foreground/5 shadow-inner overflow-hidden">
          
          {/* Diagonal line texture */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:32px_32px] [mask-image:radial-gradient(ellipse_50%_50%_at_50%_50%,#000_70%,transparent_100%)]"></div>

          {/* Glow effect that follows the mouse */}
          <motion.div
            className="pointer-events-none absolute -inset-px rounded-xl opacity-0"
            style={{
              opacity: glowOpacity,
              background: `radial-gradient(80px at ${glowX}% ${glowY}%, hsl(var(--primary)), transparent 40%)`,
            }}
          />

          <div className="relative z-10 flex h-full flex-col justify-between p-6">
            {/* Category and Price */}
            <div className="flex items-center space-x-2 text-card-foreground">
              {categoryIcon}
              <span className="text-sm font-bold bg-primary/10 px-3 py-1 rounded-full">{category}</span>
            </div>
            
            {/* Title and Description */}
            <div className="text-card-foreground">
              <h2 className="text-2xl font-bold tracking-tight leading-tight line-clamp-2">{title}</h2>
              <div className="mt-3 text-xs text-muted-foreground space-y-1">
                {description}
              </div>
            </div>
          </div>
          
          {/* Product Image - Centered and Larger */}
          <motion.div
            className="absolute inset-0 flex items-center justify-center p-8 pointer-events-none"
            style={{ transform: "translateZ(50px)" }}
          >
            <motion.img
              src={imageSrc}
              alt={imageAlt}
              whileHover={{ scale: 1.15, y: -10 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
              className="h-48 w-48 object-contain drop-shadow-lg"
              onError={(e) => {
                e.currentTarget.src = "https://via.placeholder.com/200?text=Product";
              }}
            />
          </motion.div>
        </div>
      </motion.div>
    );
  }
);

ProductHighlightCard.displayName = "ProductHighlightCard";
