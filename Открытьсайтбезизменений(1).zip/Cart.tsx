import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { useCart } from "@/contexts/CartContext";
import { ShoppingCart, Trash2, Plus, Minus, ArrowLeft, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { useState, useEffect } from "react";

export default function Cart() {
  // Apply Montserrat font to the body when on this page
  useEffect(() => {
    document.body.style.fontFamily = "'Montserrat', sans-serif";
    return () => {
      document.body.style.fontFamily = "";
    };
  }, []);
  const [, navigate] = useLocation();
  const { items, removeItem, updateQuantity, clearCart, total } = useCart();
  const [isOrdering, setIsOrdering] = useState(false);

  const handleCheckout = () => {
    if (items.length === 0) {
      toast.error("Корзина пуста!");
      return;
    }

    setIsOrdering(true);
    setTimeout(() => {
      toast.success("Заказ успешно оформлен! 🎉", {
        description: `Сумма: $${total.toFixed(2)}`,
      });
      clearCart();
      setTimeout(() => navigate("/"), 1500);
    }, 1500);
  };

  const handleQuickBuy = () => {
    if (items.length === 0) {
      toast.error("Корзина пуста!");
      return;
    }

    setIsOrdering(true);
    setTimeout(() => {
      toast.success("Спасибо за покупку! 🚀", {
        description: `Ваш заказ на $${total.toFixed(2)} принят`,
      });
      clearCart();
      setTimeout(() => navigate("/"), 1500);
    }, 1200);
  };

  return (
    <div className="min-h-screen bg-[#F8F9FB] font-sans">
      {/* Header Navigation */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-xl border-b border-gray-100">
        <div className="max-w-2xl mx-auto px-6 py-4 flex items-center justify-between">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-3 group cursor-pointer"
          >
            <svg viewBox="0 0 256 256" className="w-6 h-6 group-hover:scale-110 transition-transform" fill="currentColor">
              <path d="M 0 128 C 70.692 128 128 185.308 128 256 L 64 256 C 64 220.654 35.346 192 0 192 Z M 256 192 C 220.654 192 192 220.654 192 256 L 128 256 C 128 185.308 185.308 128 256 128 Z M 128 0 C 128 70.692 70.692 128 0 128 L 0 64 C 35.346 64 64 35.346 64 0 Z M 192 0 C 192 35.346 220.654 64 256 64 L 256 128 C 185.308 128 128 70.692 128 0 Z" />
            </svg>
            <span className="font-bold text-lg">CoiNIS</span>
          </button>

          <h1 className="text-xl font-black text-gray-900">Корзина</h1>

          <div className="w-6" />
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-6 py-8">
        {items.length === 0 ? (
          // Empty Cart State
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-20"
          >
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <ShoppingCart className="w-12 h-12 text-gray-400" />
            </div>
            <h2 className="text-2xl font-black text-gray-900 mb-3">Корзина пуста</h2>
            <p className="text-gray-500 mb-8">Начните со Swipeee и выбирайте товары!</p>
            <button
              onClick={() => navigate("/swipeee")}
              className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-2xl font-bold hover:bg-blue-700 transition-colors"
            >
              <span>Перейти к Swipeee</span>
              <ArrowLeft className="w-4 h-4 rotate-180" />
            </button>
          </motion.div>
        ) : (
          <>
            {/* Cart Items */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-4 mb-8"
            >
              {items.map((item, index) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-white rounded-3xl p-6 border border-gray-100 shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="flex gap-6">
                    {/* Product Image */}
                    <div className="w-24 h-24 rounded-2xl overflow-hidden bg-gray-50 flex-shrink-0">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Product Info */}
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                              {item.category}
                            </p>
                            <h3 className="text-lg font-black text-gray-900">
                              {item.name}
                            </h3>
                          </div>
                          <button
                            onClick={() => removeItem(item.id)}
                            className="p-2 hover:bg-red-50 rounded-lg text-red-500 transition-colors"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-black text-blue-600">
                          ${(item.price * item.quantity).toFixed(2)}
                        </span>

                        {/* Quantity Controls */}
                        <div className="flex items-center gap-3 bg-gray-100 rounded-full p-1">
                          <button
                            onClick={() =>
                              updateQuantity(item.id, item.quantity - 1)
                            }
                            className="p-2 hover:bg-white rounded-full transition-colors"
                          >
                            <Minus className="w-4 h-4 text-gray-600" />
                          </button>
                          <span className="w-8 text-center font-bold text-gray-900">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() =>
                              updateQuantity(item.id, item.quantity + 1)
                            }
                            className="p-2 hover:bg-white rounded-full transition-colors"
                          >
                            <Plus className="w-4 h-4 text-gray-600" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>

            {/* Summary Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-3xl p-8 border border-blue-100 mb-8"
            >
              <div className="space-y-4 mb-8">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600 font-medium">Товаров:</span>
                  <span className="font-bold text-gray-900">{items.length}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600 font-medium">Количество:</span>
                  <span className="font-bold text-gray-900">
                    {items.reduce((sum, item) => sum + item.quantity, 0)}
                  </span>
                </div>
                <div className="h-px bg-gradient-to-r from-transparent via-gray-300 to-transparent" />
                <div className="flex justify-between items-center">
                  <span className="text-lg font-black text-gray-900">
                    Итого:
                  </span>
                  <span className="text-4xl font-black text-blue-600">
                    ${total.toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Promo Info */}
              <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-4 text-center mb-6">
                <p className="text-[10px] font-bold text-green-600 uppercase tracking-widest">
                  ✨ Бесплатная доставка при заказе от $50
                </p>
              </div>
            </motion.div>

            {/* Action Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="space-y-3 mb-8"
            >
              <button
                onClick={handleCheckout}
                disabled={isOrdering}
                className="w-full py-4 bg-gray-900 text-white rounded-2xl font-bold text-lg hover:bg-black transition-all active:scale-95 disabled:opacity-50 shadow-lg shadow-gray-200 flex items-center justify-center gap-2"
              >
                {isOrdering ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Оформление...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-5 h-5" />
                    Оформить заказ
                  </>
                )}
              </button>

              <button
                onClick={handleQuickBuy}
                disabled={isOrdering}
                className="w-full py-4 bg-blue-600 text-white rounded-2xl font-bold text-lg hover:bg-blue-700 transition-all active:scale-95 disabled:opacity-50"
              >
                {isOrdering ? "Обработка..." : "Купить в один клик"}
              </button>

              <button
                onClick={() => navigate("/swipeee")}
                className="w-full py-4 bg-white text-gray-900 rounded-2xl font-bold text-lg border-2 border-gray-200 hover:border-gray-300 transition-all active:scale-95"
              >
                ← Вернуться к Swipeee
              </button>
            </motion.div>

            {/* Clear Cart */}
            <div className="text-center">
              <button
                onClick={() => {
                  clearCart();
                  toast.success("Корзина очищена");
                }}
                className="text-red-500 hover:text-red-600 font-medium text-sm"
              >
                Очистить корзину
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
