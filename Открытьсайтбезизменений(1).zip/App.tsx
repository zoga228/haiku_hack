import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Catalog from "./pages/Catalog";
import Wallet from "./pages/Wallet";
import Friends from "./pages/Friends";
import CoinAI from "./pages/CoinAI";
import Swipeee from "./pages/Swipeee";
import Cart from "./pages/Cart";
import Register from "./pages/Register";
import SignIn from "./pages/SignIn";
import VerifyCode from "./pages/VerifyCode";
import { CartProvider } from "./contexts/CartContext";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/catalog" component={Catalog} />
      <Route path="/wallet" component={Wallet} />
      <Route path="/friends" component={Friends} />
      <Route path="/coinai" component={CoinAI} />
      <Route path="/swipeee" component={Swipeee} />
      <Route path="/cart" component={Cart} />
      <Route path="/register" component={Register} />
      <Route path="/sign-in" component={SignIn} />
      <Route path="/verify-code" component={VerifyCode} />
      {/* Additional pages will be added one by one */}
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <CartProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </CartProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
