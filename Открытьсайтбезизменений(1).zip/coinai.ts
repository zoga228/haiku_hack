import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import axios from "axios";
import { execSync } from "child_process";
import fs from "fs";
import path from "path";

// Configure LightX API key from environment
const LIGHTX_API_KEY = process.env.LIGHTX_API_KEY || "";

// Helper to upload base64 to CDN and get URL
async function uploadToCDN(base64Data: string, filename: string): Promise<string> {
  const cleanBase64 = base64Data.replace(/^data:image\/\w+;base64,/, "");
  const tempPath = path.join("/tmp", filename);
  fs.writeFileSync(tempPath, Buffer.from(cleanBase64, "base64"));
  
  try {
    const output = execSync(`manus-upload-file ${tempPath}`).toString();
    const match = output.match(/CDN URL: (https?:\/\/[^\s]+)/);
    if (match && match[1]) return match[1];
    throw new Error("Could not find CDN URL");
  } finally {
    if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
  }
}

// Helper to poll for result
async function pollForResult(orderId: string, apiKey: string): Promise<string> {
  const maxRetries = 40; // Increase to 3+ minutes
  const interval = 5000; // 5 seconds

  for (let i = 0; i < maxRetries; i++) {
    console.log(`Polling for result (attempt ${i + 1})...`);
    const response = await axios.post(
      "https://api.lightxeditor.com/external/api/v1/order-status",
      { orderId },
      {
        headers: {
          "x-api-key": apiKey,
          "Content-Type": "application/json",
        },
      }
    );

    const status = response.data?.body?.status;
    const outputUrl = response.data?.body?.outputUrl;

    if (status === "active" && outputUrl) {
      return outputUrl;
    }

    if (status === "failed") {
      throw new Error("LightX processing failed");
    }

    await new Promise(resolve => setTimeout(resolve, interval));
  }

  throw new Error("Polling timeout");
}

export const coinaiRouter = router({
  tryOn: publicProcedure
    .input(
      z.object({
        userPhotoBase64: z.string().describe("Base64 encoded user photo"),
        clothingPhotoBase64: z.string().describe("Base64 encoded clothing photo"),
        clothingDescription: z.string().optional().describe("Description of the clothing item"),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const { userPhotoBase64, clothingPhotoBase64, clothingDescription } = input;

        if (!LIGHTX_API_KEY) throw new Error("LIGHTX API key not configured");

        console.log("Uploading images to CDN...");
        const personUrl = await uploadToCDN(userPhotoBase64, `person_${Date.now()}.jpg`);
        const garmentUrl = await uploadToCDN(clothingPhotoBase64, `garment_${Date.now()}.jpg`);

        console.log("Initiating LightX VTO order...");
        const response = await axios.post(
          "https://api.lightxeditor.com/external/api/v2/aivirtualtryon",
          { imageUrl: personUrl, styleImageUrl: garmentUrl },
          {
            headers: { "x-api-key": LIGHTX_API_KEY, "Content-Type": "application/json" },
          }
        );

        const orderId = response.data?.body?.orderId;
        if (!orderId) throw new Error("Failed to get orderId from LightX");

        console.log(`Order initiated: ${orderId}. Starting polling...`);
        const resultUrl = await pollForResult(orderId, LIGHTX_API_KEY);

        console.log("Result image URL received:", resultUrl);

        // Download and convert result image to base64
        const imageResponse = await axios.get(resultUrl, { responseType: 'arraybuffer' });
        const resultBase64 = Buffer.from(imageResponse.data).toString("base64");

        return {
          success: true,
          resultImageBase64: resultBase64,
          resultImageUrl: resultUrl,
          analysis: {
            description: `Вот как выглядит ${clothingDescription || "эта одежда"} на вас! AI реалистично переделал вашу фотографию, надев выбранный предмет одежды.`,
            fit: "excellent",
            confidence: 9,
            suggestions: [
              "Посадка идеально соответствует вашей фигуре",
              "Цвет гармонирует с вашим тоном кожи",
              "Стиль подчеркивает вашу индивидуальность"
            ],
            colors: "Цвета гармонируют идеально",
            style_notes: "Отличный выбор для вашего стиля"
          },
          timestamp: new Date().toISOString(),
        };
      } catch (error: any) {
        console.error("Coin AI VTO error:", error.response?.data || error.message);
        throw new Error(error.response?.data?.message || error.message || "Failed to process virtual try-on");
      }
    }),

  checkStatus: publicProcedure.query(async () => ({
    available: !!LIGHTX_API_KEY,
    message: LIGHTX_API_KEY ? "LightX VTO API is ready" : "LIGHTX API key not configured",
    model: "lightx-v2-polling"
  })),
});
