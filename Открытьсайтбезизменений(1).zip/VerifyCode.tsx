import { motion } from "framer-motion";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { ChevronLeft, Mail } from "lucide-react";

export default function VerifyCode() {
  const [, navigate] = useLocation();
  const [code, setCode] = useState("");
  const [timeLeft, setTimeLeft] = useState(600); // 10 minutes
  const [userId, setUserId] = useState<number | null>(null);
  const [email, setEmail] = useState<string>("");

  const verifyMutation = trpc.emailAuth.loginStep2.useMutation({
    onSuccess: (data) => {
      toast.success(`Welcome back, ${data.user.name}!`);
      window.location.href = "/";
    },
    onError: (err) => {
      toast.error(err.message ?? "Verification failed. Please try again.");
    },
  });

  useEffect(() => {
    // Get userId and email from sessionStorage
    const storedUserId = sessionStorage.getItem("2fa_userId");
    const storedEmail = sessionStorage.getItem("2fa_email");

    if (!storedUserId || !storedEmail) {
      navigate("/sign-in");
      return;
    }

    setUserId(parseInt(storedUserId));
    setEmail(storedEmail);
  }, [navigate]);

  useEffect(() => {
    if (timeLeft <= 0) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim() || !userId) {
      toast.error("Please enter the verification code.");
      return;
    }
    if (code.length !== 6) {
      toast.error("Verification code must be 6 digits.");
      return;
    }
    verifyMutation.mutate({ userId, code: code.trim() });
  };

  const handleResend = () => {
    toast.info("Verification code resent to your email.");
    setTimeLeft(600);
  };

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Sky background */}
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage:
            "url('https://d2xsxph8kpxj0f.cloudfront.net/310519663752008614/CQve3qqPzggvAYmAyEarNa/hero-sky-clouds-1-mUDo6fjZmSX72K8BGGyxrk.webp')",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />
      {/* Gradient overlay */}
      <div className="absolute inset-0 z-[1] bg-gradient-to-b from-sky-900/20 via-white/60 to-white/90" />

      {/* Content */}
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-6 py-12">
        {/* Back to sign in */}
        <motion.a
          href="/sign-in"
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="absolute top-6 left-6 flex items-center gap-1 text-sm text-slate-600 hover:text-slate-900 transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />
          Back to sign in
        </motion.a>

        {/* Verification Card */}
        <motion.div
          initial={{ opacity: 0, y: 30, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="w-full max-w-md"
        >
          <div className="bg-white/80 backdrop-blur-xl rounded-3xl p-8 md:p-10 shadow-2xl shadow-sky-200/30 border border-white/60">
            {/* Logo & Title */}
            <div className="text-center mb-8">
              <div className="flex items-center justify-center gap-2 mb-4">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-sky-400 to-sky-600 flex items-center justify-center">
                  <Mail className="w-5 h-5 text-white" />
                </div>
              </div>
              <h1 className="text-2xl font-bold text-slate-900">Verify Your Email</h1>
              <p className="text-slate-600 text-sm mt-2">
                We've sent a 6-digit code to <strong>{email}</strong>
              </p>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Code Input */}
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">
                  Verification Code
                </label>
                <input
                  type="text"
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                  placeholder="000000"
                  maxLength={6}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-white/50 text-center text-2xl font-bold tracking-widest focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent transition-all"
                />
              </div>

              {/* Timer */}
              <div className="text-center">
                <p className="text-sm text-slate-600">
                  Code expires in{" "}
                  <span className="font-semibold text-sky-600">
                    {minutes}:{seconds.toString().padStart(2, "0")}
                  </span>
                </p>
              </div>

              {/* Submit Button */}
              <motion.button
                type="submit"
                disabled={verifyMutation.isPending || code.length !== 6}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full py-3 rounded-xl font-semibold text-white bg-gradient-to-r from-sky-500 to-sky-600 hover:from-sky-600 hover:to-sky-700 disabled:from-slate-300 disabled:to-slate-300 transition-all shadow-lg shadow-sky-200"
              >
                {verifyMutation.isPending ? "Verifying..." : "Verify Code"}
              </motion.button>

              {/* Resend Link */}
              <div className="text-center">
                <button
                  type="button"
                  onClick={handleResend}
                  className="text-sm text-sky-600 hover:text-sky-700 font-medium transition-colors"
                >
                  Didn't receive the code? Resend
                </button>
              </div>
            </form>

            {/* Footer */}
            <div className="mt-8 pt-6 border-t border-slate-200/50 text-center">
              <p className="text-xs text-slate-500">
                Your security is important to us. This code is valid for 10 minutes.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
