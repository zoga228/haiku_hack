# BFL Flux VTO API - Исследование и Решение

## Найденные проблемы

### Ошибка 422 (Unprocessable Entity)
Текущий код отправляет:
```json
{
  "image_url": "data:image/jpeg;base64,...",
  "product_image_url": "data:image/jpeg;base64,...",
  "category": "top"
}
```

### Правильная схема запроса (по документации)
Параметры должны быть:
- `prompt` (string, обязательно) - Natural-language styling instruction
- `person` (string, обязательно) - Person image as URL or base64
- `garment` (string, обязательно) - Garment reference as URL or base64
- `seed` (integer, опционально)
- `safety_tolerance` (integer, опционально) - 0 to 5, default 2
- `output_format` (string, опционально) - jpeg, png, webp, default jpeg
- `webhook_url` (URL, опционально)
- `webhook_secret` (string, опционально)

## Решение

1. **Переименовать параметры**:
   - `image_url` → `person`
   - `product_image_url` → `garment`
   - Удалить `category` (не требуется)

2. **Добавить обязательный параметр `prompt`**:
   - Использовать `clothingDescription` или сгенерировать по умолчанию
   - Формат: "The person of image 1, maintaining exactly their face and pose, wearing the {description} of image 2."

3. **Поддержка base64 и URL**:
   - BFL API поддерживает оба формата
   - base64 должен быть в формате: `data:image/jpeg;base64,{base64_data}`
   - Или просто raw base64 строка

## Примеры запросов

### curl
```bash
curl -X POST https://api.bfl.ai/v1/flux-tools/vto-v1 \
  -H "x-key: $BFL_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "The person of image 1, maintaining exactly their face and pose, wearing the blue jacket of image 2.",
    "person": "data:image/jpeg;base64,...",
    "garment": "data:image/jpeg;base64,...",
    "output_format": "jpeg"
  }'
```

### Polling
```bash
curl https://api.bfl.ai/v1/get_result?id=<TASK_ID> \
  -H "x-key: $BFL_API_KEY"
```

## Ключевые отличия от текущей реализации

1. Параметры имеют другие имена
2. Требуется параметр `prompt`
3. Нет параметра `category`
4. Polling URL может быть другим (использовать `polling_url` из ответа)
