import { useState, useRef, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Upload, Sparkles, Loader2, ChevronLeft, ChevronRight } from "lucide-react";
import { motion } from "framer-motion";

export default function CoinAI() {
  const [userPhoto, setUserPhoto] = useState<string | null>(null);
  const [clothingPhoto, setClothingPhoto] = useState<string | null>(null);
  const [clothingDescription, setClothingDescription] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStatus, setProcessingStatus] = useState("");
  const [result, setResult] = useState<any>(null);
  const [sliderPosition, setSliderPosition] = useState(50);
  const [error, setError] = useState<string | null>(null);
  
  const userPhotoRef = useRef<HTMLInputElement>(null);
  const clothingPhotoRef = useRef<HTMLInputElement>(null);
  
  const tryOnMutation = trpc.coinai.tryOn.useMutation();

  const handlePhotoUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    type: "user" | "clothing"
  ) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result as string;
        const base64Data = base64.split(",")[1]; // Remove data:image/jpeg;base64, prefix
        
        if (type === "user") {
          setUserPhoto(base64Data);
        } else {
          setClothingPhoto(base64Data);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleTryOn = async () => {
    if (!userPhoto || !clothingPhoto) {
      setError("Пожалуйста, загрузите оба фото");
      return;
    }

    setError(null);
    setIsProcessing(true);
    setProcessingStatus("Отправляем фото на обработку...");
    
    try {
      setProcessingStatus("AI анализирует вашу фигуру и одежду...");
      
      const response = await tryOnMutation.mutateAsync({
        userPhotoBase64: userPhoto,
        clothingPhotoBase64: clothingPhoto,
        clothingDescription,
      });
      
      setProcessingStatus("Генерируем результат...");
      setResult(response);
      setSliderPosition(50); // Reset slider position
    } catch (error) {
      console.error("Try-on failed:", error);
      setError(error instanceof Error ? error.message : "Ошибка при обработке. Пожалуйста, попробуйте еще раз.");
    } finally {
      setIsProcessing(false);
      setProcessingStatus("");
    }
  };

  const handleReset = () => {
    setUserPhoto(null);
    setClothingPhoto(null);
    setClothingDescription("");
    setResult(null);
    setSliderPosition(50);
    setError(null);
  };

  return (
    <DashboardLayout requireAuth={false}>
      {/* Облачный фон */}
      <div className="fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-50 via-white to-pink-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900" />
        
        {/* Облака */}
        <svg className="absolute inset-0 w-full h-full opacity-30 dark:opacity-10" viewBox="0 0 1200 600" preserveAspectRatio="none">
          <defs>
            <filter id="blur-ai">
              <feGaussianBlur in="SourceGraphic" stdDeviation="3" />
            </filter>
          </defs>
          
          <motion.g
            animate={{ x: [0, 20, 0] }}
            transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
            filter="url(#blur-ai)"
          >
            <ellipse cx="150" cy="100" rx="120" ry="50" fill="currentColor" className="text-purple-300" opacity="0.6" />
            <ellipse cx="220" cy="110" rx="100" ry="45" fill="currentColor" className="text-purple-300" opacity="0.5" />
            <ellipse cx="100" cy="120" rx="90" ry="40" fill="currentColor" className="text-purple-300" opacity="0.4" />
          </motion.g>

          <motion.g
            animate={{ x: [-20, 0, -20] }}
            transition={{ duration: 10, repeat: Infinity, ease: "easeInOut", delay: 1 }}
            filter="url(#blur-ai)"
          >
            <ellipse cx="1050" cy="150" rx="130" ry="55" fill="currentColor" className="text-pink-300" opacity="0.5" />
            <ellipse cx="1120" cy="160" rx="110" ry="50" fill="currentColor" className="text-pink-300" opacity="0.4" />
            <ellipse cx="1000" cy="170" rx="100" ry="45" fill="currentColor" className="text-pink-300" opacity="0.3" />
          </motion.g>
        </svg>
      </div>

      <div className="relative z-10 min-h-screen pt-8 pb-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-12"
          >
            <div className="flex items-center gap-3 mb-4">
              <Sparkles className="w-8 h-8 text-purple-500" />
              <h1 className="text-4xl font-bold">Coin AI</h1>
            </div>
            <p className="text-lg text-muted-foreground">Виртуальная примерка одежды с помощью искусственного интеллекта</p>
          </motion.div>

          {!result ? (
            /* Upload Section */
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Upload Area */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex flex-col gap-6"
              >
                {/* User Photo Upload */}
                <div
                  onClick={() => userPhotoRef.current?.click()}
                  className="relative group cursor-pointer"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl blur-lg opacity-25 group-hover:opacity-40 transition-opacity" />
                  <div className="relative bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm rounded-2xl p-8 border-2 border-dashed border-purple-300 hover:border-purple-500 transition-colors">
                    {userPhoto ? (
                      <div className="flex flex-col items-center gap-4">
                        <img
                          src={`data:image/jpeg;base64,${userPhoto}`}
                          alt="User"
                          className="w-full h-48 object-cover rounded-lg"
                        />
                        <p className="text-sm text-muted-foreground">Нажмите для смены фото</p>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center gap-4">
                        <Upload className="w-12 h-12 text-purple-500" />
                        <div className="text-center">
                          <p className="font-semibold">Загрузите свое фото</p>
                          <p className="text-sm text-muted-foreground">Четкое фото в хорошем освещении</p>
                        </div>
                      </div>
                    )}
                  </div>
                  <input
                    ref={userPhotoRef}
                    type="file"
                    accept="image/*"
                    onChange={(e) => handlePhotoUpload(e, "user")}
                    className="hidden"
                  />
                </div>

                {/* Clothing Photo Upload */}
                <div
                  onClick={() => clothingPhotoRef.current?.click()}
                  className="relative group cursor-pointer"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-pink-500 to-purple-500 rounded-2xl blur-lg opacity-25 group-hover:opacity-40 transition-opacity" />
                  <div className="relative bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm rounded-2xl p-8 border-2 border-dashed border-pink-300 hover:border-pink-500 transition-colors">
                    {clothingPhoto ? (
                      <div className="flex flex-col items-center gap-4">
                        <img
                          src={`data:image/jpeg;base64,${clothingPhoto}`}
                          alt="Clothing"
                          className="w-full h-48 object-cover rounded-lg"
                        />
                        <p className="text-sm text-muted-foreground">Нажмите для смены фото</p>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center gap-4">
                        <Upload className="w-12 h-12 text-pink-500" />
                        <div className="text-center">
                          <p className="font-semibold">Загрузите фото одежды</p>
                          <p className="text-sm text-muted-foreground">Фото футболки, рубашки или другой вещи</p>
                        </div>
                      </div>
                    )}
                  </div>
                  <input
                    ref={clothingPhotoRef}
                    type="file"
                    accept="image/*"
                    onChange={(e) => handlePhotoUpload(e, "clothing")}
                    className="hidden"
                  />
                </div>

                {/* Description Input */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Описание одежды (опционально)</label>
                  <Input
                    placeholder="Например: красная футболка, размер M"
                    value={clothingDescription}
                    onChange={(e) => setClothingDescription(e.target.value)}
                    className="h-12 rounded-xl"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-red-500/10 border border-red-500/20 rounded-lg p-4 text-sm text-red-600"
                  >
                    {error}
                  </motion.div>
                )}

                {/* Try On Button */}
                <Button
                  onClick={handleTryOn}
                  disabled={!userPhoto || !clothingPhoto || isProcessing}
                  className="h-12 rounded-xl text-base font-semibold bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      {processingStatus || "Обработка..."}
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Виртуальная примерка
                    </>
                  )}
                </Button>
              </motion.div>

              {/* Info Section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="flex flex-col gap-6 justify-center"
              >
                <div className="bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm rounded-2xl p-8 space-y-6">
                  <h2 className="text-2xl font-bold">Как это работает?</h2>
                  
                  <div className="space-y-4">
                    <div className="flex gap-4">
                      <div className="flex-shrink-0 w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center font-bold text-purple-600">1</div>
                      <div>
                        <h3 className="font-semibold">Загрузите фото</h3>
                        <p className="text-sm text-muted-foreground">Загрузите четкое фото себя и одежды, которую хотите примерить</p>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <div className="flex-shrink-0 w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center font-bold text-purple-600">2</div>
                      <div>
                        <h3 className="font-semibold">AI анализирует</h3>
                        <p className="text-sm text-muted-foreground">Наш AI анализирует вашу фигуру, цвет кожи и стиль</p>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <div className="flex-shrink-0 w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center font-bold text-purple-600">3</div>
                      <div>
                        <h3 className="font-semibold">Получите результат</h3>
                        <p className="text-sm text-muted-foreground">Смотрите, как вы выглядите в этой одежде с помощью AI</p>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-muted">
                    <p className="text-xs text-muted-foreground">
                      💡 Совет: Используйте четкие фото в хорошем освещении для лучших результатов
                    </p>
                  </div>
                </div>
              </motion.div>
            </div>
          ) : (
            /* Results Section */
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col gap-8"
            >
              {/* Before/After Slider */}
              <div className="flex flex-col gap-4">
                <h2 className="text-2xl font-bold">Результат примерки</h2>
                
                <div className="relative w-full h-96 rounded-2xl overflow-hidden bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm shadow-2xl">
                  {/* Before Image */}
                  <img
                    src={`data:image/jpeg;base64,${userPhoto}`}
                    alt="Before"
                    className="absolute inset-0 w-full h-full object-cover"
                  />

                  {/* After Image (Slider) */}
                  {result?.resultImageBase64 || result?.resultImageUrl ? (
                    <div
                      className="absolute inset-0 overflow-hidden"
                      style={{ width: `${sliderPosition}%` }}
                    >
                      <img
                        src={result.resultImageBase64 ? `data:image/jpeg;base64,${result.resultImageBase64}` : result.resultImageUrl}
                        alt="After"
                        className="absolute inset-0 w-full h-full object-cover"
                        style={{ width: `${100 / (sliderPosition / 100)}%` }}
                      />
                    </div>
                  ) : (
                    <div
                      className="absolute inset-0 overflow-hidden bg-gradient-to-r from-purple-500/20 to-pink-500/20 flex items-center justify-center"
                      style={{ width: `${sliderPosition}%` }}
                    >
                      <div className="text-center">
                        <Sparkles className="w-8 h-8 text-white mx-auto mb-2 animate-pulse" />
                        <p className="text-white text-sm font-medium">AI результат</p>
                      </div>
                    </div>
                  )}

                  {/* Slider Handle */}
                  <div
                    className="absolute top-0 bottom-0 w-1 bg-white cursor-col-resize group"
                    style={{ left: `${sliderPosition}%` }}
                    onMouseDown={(e) => {
                      const startX = e.clientX;
                      const container = e.currentTarget.parentElement;
                      if (!container) return;

                      const handleMouseMove = (moveEvent: MouseEvent) => {
                        const rect = container.getBoundingClientRect();
                        const newPosition = ((moveEvent.clientX - rect.left) / rect.width) * 100;
                        setSliderPosition(Math.max(0, Math.min(100, newPosition)));
                      };

                      const handleMouseUp = () => {
                        document.removeEventListener("mousemove", handleMouseMove);
                        document.removeEventListener("mouseup", handleMouseUp);
                      };

                      document.addEventListener("mousemove", handleMouseMove);
                      document.addEventListener("mouseup", handleMouseUp);
                    }}
                  >
                    <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                      <div className="flex gap-1">
                        <ChevronLeft className="w-4 h-4 text-purple-500" />
                        <ChevronRight className="w-4 h-4 text-purple-500" />
                      </div>
                    </div>
                  </div>

                  {/* Labels */}
                  <div className="absolute top-4 left-4 bg-black/50 text-white px-3 py-1 rounded-full text-sm font-medium">
                    До
                  </div>
                  <div className="absolute top-4 right-4 bg-black/50 text-white px-3 py-1 rounded-full text-sm font-medium">
                    После
                  </div>
                </div>
              </div>

              {/* Analysis Results */}
              {result?.analysis && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm rounded-2xl p-8 space-y-6"
                >
                  <div>
                    <h3 className="text-xl font-bold mb-2">Анализ примерки</h3>
                    <p className="text-muted-foreground">{result.analysis.description}</p>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-purple-500/10 rounded-lg p-4">
                      <p className="text-sm text-muted-foreground">Посадка</p>
                      <p className="text-lg font-bold text-purple-600 capitalize">{result.analysis.fit}</p>
                    </div>
                    <div className="bg-pink-500/10 rounded-lg p-4">
                      <p className="text-sm text-muted-foreground">Уверенность AI</p>
                      <p className="text-lg font-bold text-pink-600">{result.analysis.confidence}/10</p>
                    </div>
                    <div className="bg-blue-500/10 rounded-lg p-4">
                      <p className="text-sm text-muted-foreground">Цвета</p>
                      <p className="text-lg font-bold text-blue-600">Гармонируют</p>
                    </div>
                  </div>

                  {result.analysis.suggestions && result.analysis.suggestions.length > 0 && (
                    <div>
                      <h4 className="font-semibold mb-2">Рекомендации:</h4>
                      <ul className="space-y-2">
                        {result.analysis.suggestions.map((suggestion: string, idx: number) => (
                          <li key={idx} className="flex gap-2 text-sm">
                            <span className="text-purple-500">✓</span>
                            <span>{suggestion}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </motion.div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-4 justify-center">
                <Button
                  onClick={handleReset}
                  variant="outline"
                  className="h-12 rounded-xl text-base font-semibold"
                >
                  Попробовать еще раз
                </Button>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
