# Альтернативы для Virtual Try-On API

## Проблема с BFL Flux VTO
- BFL API не принимает base64 в формате `data:image/jpeg;base64,...`
- Нужны **прямые URL** на изображения, а не base64
- Ошибка: "Unable to extract dimensions from input image"

## Альтернативные решения

### 1. **Fal.ai Flux Pro VTO** ✅ РЕКОМЕНДУЕТСЯ
- **Параметры:** `human_image_url`, `garment_image_url`, `prompt`
- **Поддержка:** URL или base64 data URI
- **Документация:** https://fal.ai/models/fal-ai/flux-pro/v1/vto/api
- **Пример:**
```json
{
  "prompt": "A natural front-facing studio shot. The t-shirt is worn tucked in.",
  "human_image_url": "https://...",
  "garment_image_url": "https://..."
}
```
- **Преимущества:**
  - Отличная документация
  - Поддержка base64 data URI (не нужно загружать на сервер)
  - Более надежный API
  - Есть файловое хранилище для загрузки файлов

### 2. **Runware Virtual Try-On**
- Альтернатива, если Fal.ai не подходит
- Также требует URL или может принимать base64

### 3. **Решение для BFL (если нужно остаться с ним)**
- Загружать изображения на S3/временное хранилище
- Получать публичный URL
- Передавать URL в BFL API вместо base64

## Рекомендация
Переключиться на **Fal.ai**, так как:
1. Лучше документирован
2. Поддерживает base64 data URI (не нужно загружать файлы)
3. Более стабилен
4. Проще интегрировать

## Шаги для интеграции Fal.ai
1. Установить `@fal-ai/client`
2. Получить API ключ
3. Обновить `coinai.ts` для использования Fal.ai вместо BFL
4. Тестировать
